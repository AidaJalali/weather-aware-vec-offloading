from __future__ import annotations

import argparse
from pathlib import Path

from algorithms import GeneticOffloaderConfig
from genetic_offloader_runner import (
    config_from_json,
    config_to_json,
    run_genetic_split,
)
from random_offloader_runner import run_random_split


SOURCE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA_ROOT = SOURCE_DIR / "data" / "sumo"
DEFAULT_RESULTS_ROOT = DEFAULT_DATA_ROOT / "results"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Evaluate offloading algorithms on train or validation data."
    )
    parser.add_argument(
        "--algorithm",
        choices=("random", "genetic", "both"),
        default="both",
    )
    parser.add_argument("--split", default="val", choices=("train", "val"))
    parser.add_argument("--data-root", default=str(DEFAULT_DATA_ROOT))
    parser.add_argument("--results-root", default=str(DEFAULT_RESULTS_ROOT))
    parser.add_argument("--dataset", action="append", dest="datasets")
    parser.add_argument("--max-datasets", type=int, default=0)
    parser.add_argument("--max-timesteps", type=int, default=0)
    parser.add_argument("--batch-window", type=int, default=1)
    parser.add_argument("--seed", type=int, default=999)
    parser.add_argument("--progress-every", type=int, default=20)
    parser.add_argument("--no-progress", action="store_true")
    parser.add_argument(
        "--genetic-config",
        default=str(DEFAULT_RESULTS_ROOT / "genetic" / "genetic_config.json"),
    )
    return parser


def load_genetic_config(config_path: Path, output_dir: Path) -> GeneticOffloaderConfig:
    if config_path.exists():
        return config_from_json(config_path)

    config = GeneticOffloaderConfig()
    saved_path = output_dir / "genetic_config.json"
    config_to_json(config, saved_path)
    print(f"Genetic config not found at {config_path}; using default GA config.")
    print(f"Default GA config saved to {saved_path}")
    return config


def main() -> None:
    args = build_parser().parse_args()
    results_root = Path(args.results_root)
    max_datasets = args.max_datasets if args.max_datasets > 0 else None
    max_timesteps = args.max_timesteps if args.max_timesteps > 0 else None
    show_progress = not args.no_progress

    if args.algorithm in ("random", "both"):
        output_dir = results_root / "random"
        rows = run_random_split(
            data_root=args.data_root,
            split=args.split,
            output_file=output_dir / f"{args.split}_random_results.csv",
            summary_file=output_dir / f"{args.split}_random_summary.csv",
            dataset_names=args.datasets,
            max_datasets=max_datasets,
            max_timesteps=max_timesteps,
            seed=args.seed,
            show_progress=show_progress,
            progress_every=args.progress_every,
        )
        print(f"Random {args.split} run simulated {len(rows)} tasks.")
        print(f"Results saved to {output_dir / f'{args.split}_random_results.csv'}")
        print(f"Summary saved to {output_dir / f'{args.split}_random_summary.csv'}")

    if args.algorithm in ("genetic", "both"):
        output_dir = results_root / "genetic"
        config = load_genetic_config(Path(args.genetic_config), output_dir)
        rows = run_genetic_split(
            data_root=args.data_root,
            split=args.split,
            output_file=output_dir / f"{args.split}_genetic_results.csv",
            summary_file=output_dir / f"{args.split}_genetic_summary.csv",
            config=config,
            dataset_names=args.datasets,
            max_datasets=max_datasets,
            max_timesteps=max_timesteps,
            batch_window_seconds=args.batch_window,
            seed=args.seed,
            show_progress=show_progress,
            progress_every=args.progress_every,
        )
        print(f"Genetic {args.split} run simulated {len(rows)} tasks.")
        print(f"Results saved to {output_dir / f'{args.split}_genetic_results.csv'}")
        print(f"Summary saved to {output_dir / f'{args.split}_genetic_summary.csv'}")


if __name__ == "__main__":
    main()
